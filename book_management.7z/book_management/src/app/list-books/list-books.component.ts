import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AppService } from '../app.service';
import { AppConstant } from '../app.constant';
import { IBook } from '../book.model';

@Component({
  selector: 'app-list-books',
  templateUrl: './list-books.component.html',
  styleUrls: ['./list-books.component.css']
})
export class ListBooksComponent implements OnInit {
  booksList: Array<IBook> = [];

  constructor(private router: Router, private appService: AppService) { }

  ngOnInit() {
    this.getBooks();
  }

  onAdd(): void {
    this.router.navigate([AppConstant.addPath]);
  }
  
  onEdit(isbn: string): void {
    this.router.navigate([AppConstant.editPath.replace('{isbn}', isbn)]);
  }

  onDelete(isbn: string): void {
    this.booksList = this.appService.deleteBook(isbn);
  }

  private getBooks(): void {
    this.booksList = this.appService.getBooks();
  }

}
