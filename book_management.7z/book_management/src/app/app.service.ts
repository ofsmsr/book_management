import { Injectable } from '@angular/core';
import { AppConstant } from './app.constant';

import { IBook } from './book.model';

@Injectable()
export class AppService {

  mockData: Array<IBook> = [
    {
      name: 'Book 1',
      authorName: 'Author 1',
      category: 'Category 1',
      edition: 'first',
      price: 100,
      image: AppConstant.defaultImage,
      isbn: '1234',
    },
    {
      name: 'Book 3',
      authorName: 'Author 3',
      category: 'Category 3',
      edition: 'first',
      price: 300,
      image: AppConstant.defaultImage,
      isbn: '3234',
    },
    {
      name: 'Book 2',
      authorName: 'Author 2',
      category: 'Category 2',
      edition: 'first',
      price: 200,
      image: AppConstant.defaultImage,
      isbn: '2234',
    }
  ]

  getBooks(): Array<IBook> {
    return this.mockData;
  }

  addBook(book: IBook): void {
    this.mockData = [...this.mockData, book];
  }

  updateBook(book: IBook): void {
    this.mockData = this.mockData.map(existingBook => existingBook.isbn === book.isbn ? book : existingBook);
  }

  getBook(isbn: string): IBook {
    return this.mockData.find(book => book.isbn === isbn);
  }

  deleteBook(isbn: string): Array<IBook> {
    this.mockData = this.mockData.filter(({isbn: bookIsbn}) => isbn !== bookIsbn);
    return this.mockData;
  }

}
