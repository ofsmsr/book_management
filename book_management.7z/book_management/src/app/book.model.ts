import { Validators } from "@angular/forms";

export interface IBook {
    name: string;
    authorName: string;
    category: string;
    edition: string;
    price: number;
    image: string;
    isbn: string;
}

export type bookDetail = Array<Record<string, string | number | Array<Validators>>>;