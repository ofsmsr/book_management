import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';

import { AppService } from './app.service';

import { AppComponent } from './app.component';
import { ListBooksComponent } from './list-books/list-books.component';
import { AddEditBookComponent } from './add-edit-book/add-edit-book.component';

@NgModule({
  declarations: [
    AppComponent,
    ListBooksComponent,
    AddEditBookComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
