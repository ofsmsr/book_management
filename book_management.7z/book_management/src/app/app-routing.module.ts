import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ListBooksComponent } from './list-books/list-books.component';
import { AddEditBookComponent } from './add-edit-book/add-edit-book.component';

const routes: Routes = [
  {
    path: 'list',
    component: ListBooksComponent
  },
  {
    path: 'add',
    component: AddEditBookComponent
  },
  {
    path: 'edit/:isbn',
    component: AddEditBookComponent
  },
  {
    path: '',
    component: ListBooksComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
