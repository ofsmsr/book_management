import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { AppService } from '../app.service';

import { AppConstant } from '../app.constant';
import { bookDetailToken, bookDetailData } from './add-edit-book.value';
import { IBook, bookDetail } from '../book.model';

@Component({
  selector: 'app-add-edit-book',
  templateUrl: './add-edit-book.component.html',
  styleUrls: ['./add-edit-book.component.css'],
  providers: [{
    provide: bookDetailToken,
    useValue: bookDetailData
  }]
})
export class AddEditBookComponent implements OnInit {
  bookForm: FormGroup;
  currentISBN: string = null;
  currentImageBase64: string = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private appService: AppService,
    @Inject(bookDetailToken) private readonly defaultBookDetail: Readonly<bookDetail>) { }

  ngOnInit() {
    this.createForm();
    this.currentISBN = this.route.snapshot.params[AppConstant.isbn] || null;
    if (this.currentISBN) {
      this.updateForm(this.currentISBN);
    }
  }

  onSubmit(): void {
    const book: IBook = {...this.bookForm.getRawValue(), image: this.currentImageBase64 || this.bookForm.value.image};
    if (this.currentISBN) {
      this.appService.updateBook(book)
    } else {
      this.appService.addBook(book);
    }
    this.onCancel();
  }

  previewImage() {
    const preview = document.querySelector('#preview');
    const file = document.querySelector('input[type=file]').files[0];
    const reader = new FileReader();

    reader.addEventListener("load",() => {
      preview.src = reader.result;
      this.currentImageBase64 = reader.result as string;
    }, false);

    if (file) {
      reader.readAsDataURL(file);
    }
  }

  onCancel(): void {
    this.router.navigate([AppConstant.listPath]);
  }

  private createForm(): void {
    const formDetails = {};
    this.defaultBookDetail.forEach(item => {
      formDetails[item.fieldName as string] = [item.defaultValue, item.validators]
    });
    this.bookForm = this.fb.group(formDetails);
  }

  private updateForm(isbn: string): void {
    this.bookForm.get('isbn').disable();
    this.bookForm.patchValue(this.appService.getBook(isbn));
  }

}
