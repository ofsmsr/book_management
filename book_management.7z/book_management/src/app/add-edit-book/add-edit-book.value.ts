import { InjectionToken } from '@angular/core';
import { Validators } from '@angular/forms';

import { bookDetail } from '../book.model';

export const bookDetailToken = new InjectionToken<bookDetail>('Book Detail');

export const bookDetailData: bookDetail  = [
  {
    fieldName: 'isbn',
    label: 'ISBN',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a ISBN'
  },
  {
    fieldName: 'name',
    label: 'Book Name',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Book Name'
  },
  {
    fieldName: 'authorName',
    label: 'Author Name',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Author Name'
  },
  {
    fieldName: 'category',
    label: 'Category',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Category'
  },
  {
    fieldName: 'edition',
    label: 'Edition',
    type: 'text',
    defaultValue: '',
    validators: [Validators.required],
    validationMessage: 'Please provide a Edition'
  },
  {
    fieldName: 'price',
    label: 'Price',
    type: 'number',
    defaultValue: null,
    validators: [Validators.required],
    validationMessage: 'Please provide a Price'
  },
  {
    fieldName: 'image',
    label: 'Image',
    type: 'file',
    defaultValue: '',
    validators:[]
  }
];
